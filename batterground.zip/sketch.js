class Button {
    constructor(label, x, y, isCircle = false, action = null) {
        this.label = label;
        this.x = x;
        this.y = y;
        this.diameter = 50;
        this.isCircle = isCircle;
        this.fontSize = 16;
        this.action = action;
    }

    display() {
        if (this.isHovered() && !settingMenu) {
            fill(100, 150, 255);
        } else {
            fill(200);
        }

        if (this.isCircle) {
            ellipse(this.x, this.y, this.diameter);
        } else {
            rectMode(CENTER);
            rect(this.x, this.y, 200, 50, 10);
        }

        fill(0);
        textSize(this.fontSize);
        text(this.label, this.x, this.y);
    }

    isHovered() {
        if (this.isCircle) {
            return dist(mouseX, mouseY, this.x, this.y) < this.diameter / 2;
        } else {
            return (
                mouseX > this.x - 100 &&
                mouseX < this.x + 100 &&
                mouseY > this.y - 25 &&
                mouseY < this.y + 25
            );
        }
    }
}

// Game variables
let buttons = [];
let gameState = "menu"; 
let settingMenu = false;
let modal;

function setup() {
    createCanvas(600, 400);
    textAlign(CENTER, CENTER);
    textSize(32);

    // Main Menu Buttons
    buttons.push(new Button("Start Game", width / 2, 260, false, () => gameState = "loadGame"));
    buttons.push(new Button("S", width - 75, height - 35, true, () => settingMenu = true));
    buttons.push(new Button("C", width - 150, height - 35, true, () => alert("Credits Screen Placeholder")));

    createModal();
}

function draw() {
    background(0); // Black background

    if (gameState === "menu") {
        drawMainMenu();
    } else if (gameState === "loadGame") {
        drawLoadScreen();
    }

    if (settingMenu) {
        showSettings();
    }
}

function drawMainMenu() {
    fill(255, 215, 0);
    textSize(60);
    textStyle(BOLD);
    text("Batterground", width / 2, height * 0.2);

    textStyle(NORMAL);
    for (let btn of buttons) {
        btn.display();
    }
}

function drawLoadScreen() {
    fill(255, 215, 0);
    textSize(60);
    textStyle(BOLD);
    text("Load Game", width / 2, height * 0.2);

    let loadButtons = [
        new Button("Game 1", width / 2, 200),
        new Button("Game 2", width / 2, 270),
        new Button("Game 3", width / 2, 340),
        new Button("B", 100, height - 50, true, goBack)
    ];

    for (let btn of loadButtons) {
        btn.display();
    }
}

function mousePressed() {
    if (!settingMenu) {
        for (let btn of buttons) {
            if (btn.isHovered() && btn.action) {
                btn.action();
            }
        }
    }
}

function goBack() {
    gameState = "menu";
}

// Modal (Settings Menu)
function createModal() {
    const style = document.createElement("style");
    style.textContent = `
        .modal {
            position: fixed;
            display: none;
            align-items: center;
            justify-content: center;
            left: 50%;
            top: 50%;
            transform: translate(-50%, -50%);
        }
        .modal-content {
            border: 1px solid #000000;
            background: #FFFFFF;
            padding: 20px;
            border-radius: 8px;
            text-align: center;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
            width: 300px;
            max-width: 80%;
        }
        .modal-button {
            background: #DCDCDC;
            border: 1px solid #000000;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            margin-top: 10px;
            font-weight: bold;
            color: #000000; 
        }
        .modal-button:hover {
            background-color: #6495FF;
            color: #000000;
        }
        .close-button {
            cursor: pointer;
            color: #000000;
            font-size: 20px;
            float: right;
        }
    `;
    document.head.appendChild(style);

    modal = document.createElement("div");
    modal.classList.add("modal");
    modal.innerHTML = `
        <div class="modal-content">
            <span class="close-button">&times;</span>
            <p><b>Settings</b></p>
            <button id="muteToggle" class="modal-button">Mute</button>
<button id ="unmuteToggle" class="modal-button">Unmute</button>
            <button id="backSettings" class="modal-button">Back</button>
        </div>
    `;
    document.body.appendChild(modal);

    const closeButton = modal.querySelector(".close-button");
    const muteButton = modal.querySelector("#muteToggle");
    const backButton = modal.querySelector("#backSettings");

    closeButton.addEventListener("click", hideSettings);
    muteButton.addEventListener("click", () => console.log("Mute/Unmute button clicked"));
    backButton.addEventListener("click", hideSettings);
}

function showSettings() {
    modal.style.display = "flex";
}

function hideSettings() {
    settingMenu = false;
    modal.style.display = "none";
}

function keyPressed() {
    if (keyCode === ESCAPE) {
        goBack();
    }
}
